package com.ifpe.quizzical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PibicApplication {

	public static void main(String[] args) {
		SpringApplication.run(PibicApplication.class, args);
	}

}
