package com.ifpe.quizzical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PibicApplicationTests {

	@Test
	void contextLoads() {
	}

}
